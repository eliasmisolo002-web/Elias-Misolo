
# HASTS416 - A1


library(markovchain)


# Defining the 5-state Markov Chain

states_A1 <- as.character(1:5)
P_A1 <- matrix(c(
  1.0, 0,   0,   0,   0,
  0.5, 0,   0,   0, 0.5,
  0.2, 0,   0,   0, 0.8,
  0,   0, 1.0,  0,   0,
  0,   0, 0,    1.0, 0
), nrow=5, byrow=TRUE)

mc_A1 <- new("markovchain", states=states_A1, byrow=TRUE, transitionMatrix=P_A1, name="A1")

# ===============================
# Saving all outputs to text file
# ===============================
sink("A1_Output.txt")  # All printed output goes here

cat("===== A1: 5-State Markov Chain =====\n\n")

# (a) The Diagram and Classification
cat("===== (a) Diagram and State Classification =====\n")
cat("Transient Classes:\n"); print(transientClasses(mc_A1))
cat("\nRecurrent Classes:\n"); print(recurrentClasses(mc_A1))
cat("\nAbsorbing States:\n"); print(absorbingStates(mc_A1))
cat("\nPeriod of States:\n"); print(period(mc_A1))

# (b) Simulatting Three Trajectories
cat("\n===== (b) Simulated Trajectories =====\n")
set.seed(42)
for(i in 1:3){
  start <- sample(states_A1, 1)
  traj <- rmarkovchain(n=20, object=mc_A1, t0=start)
  cat("\nTrajectory", i, "starting at state", start, ":\n")
  print(traj)
}

# (c) Steady-State Probabilities
cat("\n===== (c) Steady-State Probabilities =====\n")
ss <- steadyStates(mc_A1)
print(ss)
cat("\nIs the chain ergodic?\n")
print(is.irreducible(mc_A1))

# (d) Convergence of Unconditional Probabilities
cat("\n===== (d) Convergence of Unconditional Probabilities =====\n")
cat("See saved plots: 'A1_ChainDiagram.png' and 'A1_Convergence.png'\n")

sink()  # Stop saving text

# ===============================
# (a) Plot Chain Diagram - PNG
# ===============================
png("A1_ChainDiagram.png", width=800, height=600)
plot(mc_A1, main="A1: 5-State Markov Chain Diagram")
dev.off()

# ===============================
# (d) Plot Convergence to Steady-State - PNG
# ===============================
png("A1_Convergence.png", width=800, height=600)
initial_prob <- rep(0.2,5)
n_steps <- 20
prob_matrix <- matrix(NA, nrow=n_steps, ncol=5)
for(n in 1:n_steps){
  prob_matrix[n, ] <- initial_prob %*% (mc_A1 ^ n)
}
matplot(1:n_steps, prob_matrix, type="l", lty=1, col=1:5,
        xlab="Time (n)", ylab="State Probability",
        main="A1: Unconditional Probabilities vs Time")
legend("right", legend=states_A1, col=1:5, lty=1)
dev.off()


# HASTS416 - A2

library(markovchain)

# Define the 7-state Markov Chain
states_A2 <- as.character(1:7)
P_A2 <- matrix(c(
  0,   1,   0,   0,   0,   0,   0,
  1,   0,   0,   0,   0,   0,   0,
  0,   0,   0,   0.4, 0.2, 0.2, 0.2,
  0,   0,   0,   0,   0.2, 0.4, 0.4,
  0.3, 0,   0,   0.1, 0.3, 0.1, 0.2,
  0,   0,   0,   0.2, 0.2, 0.3, 0.3,
  0,   0,   0,   0.5, 0.2, 0.2, 0.1
), nrow=7, byrow=TRUE)

mc_A2 <- new("markovchain", states=states_A2, byrow=TRUE, transitionMatrix=P_A2, name="A2")

# Save outputs to text file
sink("A2_Output.txt")

cat("===== A2: 7-State Markov Chain =====\n\n")

# (a) Look at the diagram and classify states
cat("===== (a) Diagram and State Classification =====\n")
cat("Transient Classes:\n"); print(transientClasses(mc_A2))
cat("\nRecurrent Classes:\n"); print(recurrentClasses(mc_A2))
cat("\nAbsorbing States:\n"); print(absorbingStates(mc_A2))
cat("\nPeriod of States:\n"); print(period(mc_A2))

# (b) Simulate two sample trajectories
cat("\n===== (b) Simulated Trajectories =====\n")
set.seed(123)
for(i in 1:2){
  start <- sample(states_A2, 1)
  traj <- rmarkovchain(n=30, object=mc_A2, t0=start)
  cat("\nTrajectory", i, "starting at state", start, ":\n")
  print(traj)
}

# (c) Limiting (steady-state) probabilities
cat("\n===== (c) Limiting Probabilities =====\n")
ss <- steadyStates(mc_A2)
print(ss)
cat("\nCheck if the chain is ergodic:\n")
print(is.irreducible(mc_A2))

sink()  # Stop saving text

# Save the chain diagram
png("A2_ChainDiagram.png", width=800, height=600)
plot(mc_A2, main="7-State Markov Chain Diagram")
dev.off()

# ===============================
# HASTS416 - Assignment A3
# ===============================

library(markovchain)

# ===============================
# Define traffic states
# ===============================
states_traffic <- c("light", "heavy", "jammed")

# ===============================
# Transition probabilities 1 PM to 4 PM
# Row sums must be exactly 1
# ===============================
P_1to4 <- matrix(c(
  0.4, 0.4, 0.2,
  0.3, 0.5, 0.2,   # corrected sum = 1
  0,   0.1, 0.9
), nrow=3, byrow=TRUE)

# ===============================
# Transition probabilities 4 PM to 6 PM
# ===============================
P_4to6 <- matrix(c(
  0.1, 0.5, 0.4,
  0.1, 0.3, 0.6,
  0,   0.1, 0.9
), nrow=3, byrow=TRUE)

# ===============================
# Create Markov chain objects
# ===============================
mc_1to4 <- new("markovchain", states=states_traffic, byrow=TRUE, transitionMatrix=P_1to4, name="Traffic_1to4")
mc_4to6 <- new("markovchain", states=states_traffic, byrow=TRUE, transitionMatrix=P_4to6, name="Traffic_4to6")

# ===============================
# Save all outputs to text file
# ===============================
sink("A3_Output.txt")

cat("===== A3: Traffic Markov Chain =====\n\n")

# (a) Distribution at 6 PM if traffic starts light at 1 PM
cat("===== (a) Analytical Distribution at 6 PM =====\n")
initial_state <- c(1, 0, 0) # starting at 'light'

# 1 PM to 4 PM = 3 hours = 180 mins / 20 min steps = 9 steps
dist_4PM <- initial_state %*% (mc_1to4 ^ 9)

# 4 PM to 6 PM = 2 hours = 120 mins / 20 min steps = 6 steps
dist_6PM <- dist_4PM %*% (mc_4to6 ^ 6)

cat("Distribution at 6 PM starting from 'light' at 1 PM:\n")
print(dist_6PM)

# (b) Simulate 10,000 trajectories to verify
cat("\n===== (b) Simulation of 10,000 Trajectories =====\n")
n_sims <- 10000
final_states <- character(n_sims)

set.seed(99)
for (i in 1:n_sims){
  current_state <- "light"
  # 1 PM to 4 PM
  for(step in 1:9){
    probs <- mc_1to4@transitionMatrix[current_state, ]
    current_state <- sample(states_traffic, 1, prob = probs)
  }
  # 4 PM to 6 PM
  for(step in 1:6){
    probs <- mc_4to6@transitionMatrix[current_state, ]
    current_state <- sample(states_traffic, 1, prob = probs)
  }
  final_states[i] <- current_state
}

simulated_dist <- prop.table(table(final_states))
cat("Simulated distribution at 6 PM:\n")
print(simulated_dist)

sink()  # stop saving text

# ===============================
# (a) Plot Markov chain diagrams
# ===============================
png("A3_Chain_1to4.png", width=800, height=600)
plot(mc_1to4, main="Traffic: 1 PM to 4 PM")
dev.off()

png("A3_Chain_4to6.png", width=800, height=600)
plot(mc_4to6, main="Traffic: 4 PM to 6 PM")
dev.off()